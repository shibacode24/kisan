@extends('layout')

@section('content')

<div class="page-content-wrap">
    <div class="row">
        <div class="col-md-12" style="margin-top:20px;">
            <!-- START DEFAULT DATATABLE -->
            <div class="panel panel-default">

                <h5 class="panel-title" style="color:#FFFFFF; background-color:#0f903f; width:100%; font-size:14px;" align="center"><i class="fa fa-users"></i> &nbsp;Assign Team</h5>

                <div class="panel-body" style="margin-top:-10px; margin-bottom:5px;">
                    <div class="form-group">
                        <form role="form" method="POST" action="{{route('create-assign_team')}}">
                            @csrf
                            <div class="col-md-12">
                                <div class="form-group" style="margin-top:-10px;">

                                    <!-- 
                                                <div class="col-md-4" style="margin-top:15px;">
                                                      <label>Select Customer Type<font color="#FF0000">*</font></label>              
                                                    <select class="form-control select">
                                                        <option>Person</option>
                                                        <option>Hotel</option>
                                                    </select>
                                                </div> -->
                                    <div class="col-md-2" style="margin-top:15px;">
                                        <label>Select SM<font color="#FF0000">*</font></label>
                                        <select class="form-control select " data-live-search="true" name="sm">
                                            <option>None</option>

                                            <option>Person1</option>
                                            <option>Person2</option>
                                            <option>Person3</option>
                                            <option>Person4</option>
                                        </select>
                                    </div>
                                    <div class="col-md-2" style="margin-top:15px;">
                                        <label>Select ASM<font color="#FF0000">*</font></label>
                                        <select class="form-control select" data-live-search="true" name="asm">
                                            <option>None</option>

                                            <option>Person1</option>
                                            <option>Person2</option>
                                            <option>Person3</option>
                                            <option>Person4</option>
                                        </select>
                                    </div>
                                    <div class="col-md-2" style="margin-top:15px;">
                                        <label>Select SP<font color="#FF0000">*</font></label>

                                        <select multiple class="form-control select" data-live-search="true" name="sp">
                                            <option>None</option>
                                            <option>Person1</option>
                                            <option>Person2</option>
                                            <option>Person3</option>
                                            <option>Person4</option>
                                        </select>
                                    </div>


                                    <div class="col-md-2" style="margin-top:15px;">
                                        <label>Area<font color="#FF0000">*</font></label>
                                        <select class="form-control select" data-live-search="true" name="area">
                                            <option>None</option>
                                            <option>Person1</option>
                                            <option>Person2</option>
                                            <option>Person3</option>
                                            <option>Person4</option>
                                        </select>
                                    </div>
                                    <div class="col-md-2" style="margin-top:7vh;">
                                        <label>City : <font color="#FF0000">Wardha</font></label>
                                        <!-- <input type="text" placeholder=" " class="form-control" required/> -->
                                    </div>

                                    <div class="col-md-2" style="margin-top:7vh;">
                                        <label>State : <font color="#FF0000">Maharashtra</font></label>
                                        <!-- <input type="text" placeholder=" " class="form-control" required/> -->
                                    </div>

                                    <div class="col-md-12" style="margin-top:3vh;" align="right">

                                        <div class="input-group" style=" margin-bottom:15px;">

                                            <button type="submit" name="assign" value="Assign" class="btn btn-primary"><span class="fa fa-plus"></span> Submit </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                    </div>
                    </form>
                </div>
            </div>
        </div>


        <div>
            <div>
                <!-- END DEFAULT DATATABLE -->
                <!-- 


                            <div class="col-md-3"></div> -->
                <div class="row">
                    <div class="col-md-12">
                        <div class="panel panel-default">
                            <h5 class="panel-title" style="color:#FFFFFF; background-color:#0f903f; width:100%; font-size:14px;" align="center"><i class="fa fa-users"></i> Assigned Team</h5>

                            <div class="panel-body">
                                <table class="table datatable">
                                    <thead>
                                        <tr>
                                            <th>Sr.no.</th>
                                            <th>Name of SM</th>
                                            <th>Name of ASM</th>
                                            <th>Name of SP</th>
                                            <th>Area</th>
                                            <th>City</th>
                                            <th>State</th>

                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        
                                        @foreach ($assigns as $assign)
                                        <tr>
                                            <th>{{$loop->index+1}}</th>
                                            <td>{{$assign->Select_SM}}</td>
                                            <td>{{$assign->Select_ASM}}</td>
                                            <td>{{$assign->Select_SP}}</td>
                                            <td>{{$assign->Area}}</td>
                                            <td>{{$assign->City}}</td>
                                            <td>{{$assign->State}}</td>
                                            <td>
                                                <a href="{{route('edit-assign_team',$assign->id)}}"><button style="background-color:#0066cc; border:none; max-height:25px; margin-top:-5px; margin-bottom:-5px;" type="button" class="btn btn-info" data-toggle="tooltip" data-placement="top" title="Edit "><i class="fa fa-edit" style="margin-left:5px;"></i></button>
                                                </a>
                                                <a href="{{route('destroy-assign_team',$assign->id)}}">
                                                    <button style="background-color:#ff0000; border:none; max-height:25px; margin-top:-5px; margin-bottom:-5px;" type="button" class="btn btn-info" data-toggle="tooltip" data-placement="top" title="Delete "><i class="fa fa-trash-o" style="margin-left:5px;"></i></button>
                                                </a>
                                            </td>
                                        </tr>
                                        @endforeach
                                
                                    </tbody>
                                </table>
                            </div>
                        </div>


                    </div>
                </div>


            </div>
        </div>
        <!-- PAGE CONTENT WRAPPER -->
    </div>
    <!-- END PAGE CONTENT -->
</div>
<!-- END PAGE CONTAINER -->

@stop