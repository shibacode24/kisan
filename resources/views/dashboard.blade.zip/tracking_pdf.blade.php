<html>

<body>
    <table style="width: 863px;">
        <tbody>
            <tr style="height: 478px;">
                <td style="width: 853px; height: 478px;">
                    <p style="text-align: center;"><strong>Kisan 27</strong></p>
                    <p><strong>Tracking</strong></p>
                    <p>&nbsp;</p>
                    <table style="width: 820px;" border="1">
                        <tbody>
                            <tr>
                                <td style="width: 52px; text-align: center;">
                                    <p>1</p>
                                </td>
                                <td style="width: 242.672px; text-align: center;">
                                    <p>Employee Id</p>
                                </td>
                                <td style="width: 501.328px;">
                                    <p>&nbsp;</p>
                                </td>
                            </tr>
                            <tr>
                                <td style="width: 52px; text-align: center;">
                                    <p>2</p>
                                </td>
                                <td style="width: 242.672px; text-align: center;">
                                    <p>Employee Name</p>
                                </td>
                                <td style="width: 501.328px;">
                                    <p>&nbsp;</p>
                                </td>
                            </tr>
                            <tr>
                                <td style="width: 52px; text-align: center;">
                                    <p>3</p>
                                </td>
                                <td style="width: 242.672px; text-align: center;">
                                    <p>Employee</p>
                                </td>
                                <td style="width: 501.328px;">
                                    <p>&nbsp;</p>
                                </td>
                            </tr>
                            <tr>
                                <td style="width: 52px; text-align: center;">
                                    <p>4</p>
                                </td>
                                <td style="width: 242.672px; text-align: center;">
                                    <p>Start Date</p>
                                </td>
                                <td style="width: 501.328px;">
                                    <p>&nbsp;</p>
                                </td>
                            </tr>
                            <tr>
                                <td style="width: 52px; text-align: center;">
                                    <p>5</p>
                                </td>
                                <td style="width: 242.672px; text-align: center;">
                                    <p>End Date</p>
                                </td>
                                <td style="width: 501.328px;">
                                    <p>&nbsp;</p>
                                </td>
                            </tr>
                            <tr>
                                <td style="width: 52px; text-align: center;">
                                    <p>6</p>
                                </td>
                                <td style="width: 744px;" colspan="2" rowspan="2">
                                    <p>&nbsp;</p>
                                </td>
                            </tr>
                            <tr>
                                <td style="width: 52px;">
                                    <p>&nbsp;</p>
                                </td>
                            </tr>
                            <tr>
                                <td style="width: 52px;">
                                    <p>&nbsp;</p>
                                </td>
                                <td style="width: 242.672px;">
                                    <p>&nbsp;</p>
                                </td>
                                <td style="width: 501.328px;">
                                    <p>&nbsp;</p>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                    <p>&nbsp;</p>
                </td>
            </tr>
        </tbody>
    </table>
</body>

</html>