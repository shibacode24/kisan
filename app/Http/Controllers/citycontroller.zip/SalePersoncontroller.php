<?php

namespace App\Http\Controllers;

use App\Models\SalePerson;
use Illuminate\Http\Request;
use App\Models\state;
use App\Models\tehsil;
use App\Models\Distric;
use App\Models\city;
use App\Models\region;
use Facade\FlareClient\Stacktrace\File;
use Hash;
class SalePersoncontroller extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $saleperson = SalePerson::join('state', 'State.id', '=', 'sales_person.State_id')
            ->join('distric', 'Distric.id', '=', 'sales_person.District_id')
            ->join('tehsil', 'Tehsil.id', '=', 'sales_person.Tehsil_id')
            ->join('city', 'city.id', '=', 'sales_person.City_id')
            ->join('region', 'region.id', '=', 'sales_person.Region_id')
            ->orderby('sales_person.id', 'desc')
            ->select('sales_person.*', 'state.State_Name', 'distric.District', 'tehsil.Tehsil', 'city.City', 'region.Region')
            ->get();


        $state = state::all();
        $districs = Distric::all();
        $tehsils = tehsil::all();
        $citys = city::all();
        $regions = region::all();

        return view('sales_person', ['salepersons' => $saleperson, 'states' => $state, 'districs' => $districs, 'tehsils' => $tehsils, 'citys' => $citys, 'regions' => $regions]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {

        $request->validate([
            'role'  => 'required|max:6',
            'emp_id'  => 'required|max:6',
            'photo'  => 'required',
            'name'  => 'required|max:30',
            'no'  => 'required|min:10',
            'email'  => 'required|max:30',
            'add'  => 'required',
            'asm'  => 'required|max:20',
            'smno'  => 'required|min:10',
            'hrn'   => 'required|max:40',
            'hremail'  => 'required|max:40',
            'hrno'  => 'required|min:10',
            'location'  => 'required',
            'user' => 'required',
           'pass' => 'required',
           'city'   => 'required',
           'state'  => 'required',
           'distric'  => 'required',
           'tehsil'  => 'required',
           'region' => 'required'
         ]);


        $saleperson = new saleperson();
        $saleperson->Select_Role = $request->get('role');
        $saleperson->Emp_id = $request->get('emp_id');
        $saleperson->Photo=$request->get('photo'); 

        // if ($request->hasFile('image')) {
            
        //     $file = $request->file('image');
        //     $filename = time() . '.' . $file->getClientOriginalExtension();
        //     $file->move('public/upload_img/', $filename);
        //     $saleperson->image=$filename;
        // }
        // dd($request->all());
        
        $saleperson->Name = $request->get('name');
        $saleperson->Mobile_Number = $request->get('no');
        $saleperson->Email = $request->get('email');
        $saleperson->Address = $request->get('add');
        $saleperson->ASM_Name = $request->get('asm');
        $saleperson->SM_No = $request->get('smno');
        $saleperson->HR_Name = $request->get('hrn');
        $saleperson->HR_Email = $request->get('hremail');
        $saleperson->HR_Number = $request->get('hrno');
        $saleperson->City_id = $request->get('city');
        $saleperson->State_id = $request->get('state');
        $saleperson->District_id = $request->get('distric');
        $saleperson->Tehsil_id = $request->get('tehsil');
        $saleperson->Region_id = $request->get('region');
        $saleperson->Location = $request->get('location');
        $saleperson->Username = $request->get('user');
        $saleperson->Password = Hash::make($request->get('pass'));

        $saleperson->save();

        return redirect()->back()->with(['success'=>true,'message'=>'Successfully Submitted !']);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\SalePerson  $salePerson
     * @return \Illuminate\Http\Response
     */
    public function show(SalePerson $salePerson)
    {
        //
    }

   
    public function edit($id)
    {
        $saleperson_edit = SalePerson::find($id);
        $saleperson_all = SalePerson::join('state', 'state.id', '=', 'sales_person.State_id')
            ->join('distric', 'distric.id', '=', 'sales_person.District_id')
            ->join('tehsil', 'tehsil.id', '=', 'sales_person.Tehsil_id')
            ->join('city', 'city.id', '=', 'sales_person.City_id')
            ->join('region', 'region.id', '=', 'sales_person.Region_id')
            ->orderby('sales_person.id', 'desc')
            ->select('sales_person.*', 'state.State_Name', 'distric.District', 'tehsil.Tehsil', 'city.City', 'region.Region')
            ->get();


        $state = state::all();
        $districs = Distric::all();
        $tehsils = tehsil::all();
        $citys = city::all();
        $regions = region::all();

        return view('edit_sales_person', ['saleperson_edit' => $saleperson_edit, 'salepersons' => $saleperson_all, 'states' => $state, 'districs' => $districs, 'tehsils' => $tehsils, 'citys' => $citys, 'regions' => $regions]);
    }

   
    public function update(Request $request)
    {
        SalePerson::where('id', $request->id)->update(
            [   
                'Select_Role'=>$request->role,
                'Emp_id' => $request->emp_id,
                'Photo' => $request->photo,
                'Name' => $request->name,
                'Mobile_Number' => $request->no,
                'Email' => $request->email,
                'Address' => $request->add,
                'ASM_Name' => $request->asm,
                'SM_No' => $request->smno,
                'HR_Name' => $request->hrn,
                'HR_Email' => $request->hremail,
                'HR_Number' => $request->hrno,
                'City_id' => $request->city,
                'Region_id' => $request->region,
                'State_id' => $request->state,
                'District_id' => $request->distric,
                'Tehsil_id' => $request->tehsil,
                'Location' => $request->location,
                'Username' => $request->user,
                'Password' => $request->pass,
            ]
        );
        return redirect()->route('sales_person-index')->with(['success' => true, 'message' => 'Successfully Updated !']);
    }
    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\SalePerson  $salePerson
     * @return \Illuminate\Http\Response
     */
    public function destroy(SalePerson $salePerson, $id)
    {
        $saleperson = SalePerson::where('id', $id)->delete();
        return redirect(route('sales_person-index'))->with(['success'=>true,'message'=>'Successfully Deleted !']);
    }

    function get_district_by_id(Request $request)
    {
        $data = Distric::where('State_id', $request->id)->orderby('District', 'asc')->get();
        return response()->json($data);
    }

    function get_tehsil_by_id(Request $request)
    {
        $data = tehsil::where('District_id', $request->id)->orderby('Tehsil', 'asc')->get();
        return response()->json($data);
    }
    function get_city_by_id(Request $request)
    {
        $data = city::where('Tehsil_id', $request->id)->orderby('city', 'asc')->get();
        return response()->json($data);
    }

    function get_region_by_id(Request $request)
    {
        $data = Region::where('State_id', $request->id)->orderby('region', 'asc')->get();
        return response()->json($data);
    }

}
