<?php
namespace App\Http\Controllers;
use App\Models\User;
use App\Models\Attendance;
use App\Models\Journeyplan;
use App\Models\state;
use App\Models\Distric;
use App\Models\Region;
use App\Models\tehsil;
use App\Models\city;
use App\Models\Assignteam;
use App\Models\sm_to_asm;
use App\Models\asm_to_sp;
use App\Models\Get_photo;
use App\Models\tracking;
use DB;





use Illuminate\Http\Request;
use Hash;
class Apicontroller extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
               $user=User::get();
               return response()->json(['status'=>true,'data'=>$user]); //array
            //    return response()->json(['status'=>false,'message'=>'data not']); //array
    }
 public function login_api(Request $request)
 {
   $checkuser=User::where('username',$request->username)->first(); //we are checking first record. 'username' is a table field and $req->username is the data requested by the other person, And first()--this is for checking first record
      if($checkuser && Hash::check($request->password,$checkuser->password))
     {
    return response()->json(['status'=>true,'data'=>$checkuser]); //array
     }
      else
      {
    return response()->json(['status'=>false,'message'=>'User Not Found']); //array
     }
 }
 public function attendance(Request $request)
 {
  
    $insert=Attendance::create(
        [
     'user_id'=>$request->user_id, //user-id ye table field hai oe $req->user-id ye data form se aa raha hai
     'time'=>date('G:i',strtotime($request->time)),
     'date'=>$request->date,
    'in_out'=>$request->in_out,
    ]);
    if($insert->id)
    {
        return response()->json(['status'=>true,'message'=>'Attendance Recorded Successfully']);
    }
    else{
        return response()->json(['status'=>false,'message'=>'Something Error Occure At Server']);
    }
 }
public function check_in_out(Request $request)
{
  $check_in_out=attendance::where('user_id',$request->user_id)->where('in_out','in')
  ->where('date',date('Y-m-d'))->OrderBy('id','desc')->first();
  if($check_in_out)
  {
    return response()->json(['status'=>true,'message'=>'Record Found']);
  }
  else{
    return response()->json(['status'=>false,'message'=>'Record Not Found']);
  }
}
public function show_journeyplan(Request $request)
{
    $data=Journeyplan::
    join('state','state.id','=','journeyplan.State_id')
    ->join('distric','distric.id','=','journeyplan.District_id')
    ->join('tehsil','tehsil.id','=','journeyplan.Tehsil_id')
    ->where('user_id',$request->user_id)
    ->select('journeyplan.*','state.State_Name','distric.District','tehsil.Tehsil')
    ->get();
    if(count($data)>0)
    // if($data)
    return response()->json(['status'=>true,'data'=>$data]);
    else
    return response()->json(['status'=>false,'data'=>'data not found']);

}

public function journeyplan(Request $request)
 {
    $insert=Journeyplan::create(
        [
     'user_id'=>$request->user_id, //user-id ye table field hai oe $req->user-id ye data form se aa raha hai
     'project_type'=>$request->projecttype,
     'journey_plan_type'=>$request->journeyplan,
     'visit_type'=>$request->visittype,
     'traveling_date'=>date('Y-m-d',strtotime($request->travelingdate)),
     'from_time'=>date('G:i',strtotime($request->fromdate)),
     'to_time'=>date('G:i',strtotime($request->todate)),
     'State_id'=>$request->state,
     'District_id'=>$request->district,
     'Tehsil_id'=>$request->tahsil,
     'form_location'=>$request->formlocation,        
     'to_location'=>$request->tolocation,
     'mode_of_travel'=>$request->modeoftravel,
     'meter_reading' =>$request->meterreading, 
     'task'=>$request->task,
     'photo'=>$request->photo,
    ]);
    // dd($insert);
    if($insert->id)
    {
        return response()->json(['status'=>true,'message'=>'data submitted successfully']);
    }
    else{
        return response()->json(['status'=>false,'message'=>'something error occur']);
    }
  }

  public function journeyplandelete(Request $request)
  {
     $delete=Journeyplan::where('id',$request->id)->delete();  
        
     if($delete)
     {
         return response()->json(['status'=>true,'message'=>'data deleted successfully']);
     }
     else{
         return response()->json(['status'=>false,'message'=>'something error occur']);
     }
   }

   public function date_year(Request $request)
   {
    $date_year=Journeyplan::select( DB::raw(" MIN(DATE_FORMAT(created_at, '%Y-%m')) as date, YEAR(created_at) year, MONTH(created_at) month ") ) ->groupBy('year', 'month') ->get();

    if($date_year)
     {
         return response()->json(['status'=>true,'data'=>$date_year]);
     }
     else
     {
         return response()->json(['status'=>false,'message'=>'data not found']);
     }

   }

   public function getallstate(Request $request)
   {
    $getallstate=state::orderBy('State_Name','asc')->get();
    if($getallstate)
     {
         return response()->json(['status'=>true,'data'=>$getallstate]);
     }
     else
     {
         return response()->json(['status'=>false,'message'=>'data not found']);
     }

   }

   public function getalldistrict(Request $request)
   {
  //  {dd($request->all());
    $getalldistrict=Distric::where('State_id',$request->state_id)->orderBy('District','asc')->get();
    if($getalldistrict)
     {
         return response()->json(['status'=>true,'data'=>$getalldistrict]);
     }
     else
     {
         return response()->json(['status'=>false,'message'=>'data not found']);
     }

   }

   public function getallregion(Request $request)
   {
    $getallregion=Region::where('State_id',$request->state_id)->orderBy('Region','asc')->get();
    if($getallregion)
     {
         return response()->json(['status'=>true,'data'=>$getallregion]);
     }
     else
     {
         return response()->json(['status'=>false,'message'=>'data not found']);
     }

   }

   public function getalltehsil(Request $request)
   {

    // dd($request->all());
    $getalltehsil=tehsil::where('State_id',$request->state_id)->where('District_id',$request->district_id)->orderBy('Tehsil','asc')->get();
   

    if($getalltehsil)
     {
         return response()->json(['status'=>true,'data'=>$getalltehsil]);
     }
     else
     {
         return response()->json(['status'=>false,'message'=>'data not found']);
     }
   
   }

   public function getallcity(Request $request)
   {

    // dd($request->all());
    $getallcity=city::where('State_id',$request->state_id)->where('District_id',$request->district_id)->where('Tehsil_id',$request->tehsil_id)->orderBy('City','asc')->get();
    dd($request->all());

    if($getallcity)
     {
         return response()->json(['status'=>true,'data'=>$getallcity]);
     }
     else
     {
         return response()->json(['status'=>false,'message'=>'data not found']);
     }
   
   }

//    public function sm_to_region1(Request $request)
//    {
//       // dd($request->all());
//       // $insert=Assignteam::create(
//       //     
//            $get=Assignteam::where('Select_SM',$request->sm)->where('Region',$request->region)->orderBy('Region','asc')->get();
//       //  'Select_SM'=>$request->sm,
//       //  'Region'=>$request->region,
  
//       if($get)
//       {
//           return response()->json(['status'=>true,'data'=>$get]);
//       }
//       else{
//           return response()->json(['status'=>false,'message'=>'Something Error Occure']);
//       }
//    }



   public function sm_to_region(Request $request)
 {
    // dd($request->all());
    $insert=Assignteam::create(
        [
     'Select_SM'=>$request->sm,
     'Region'=>$request->region,
    ]);
    if($insert->id)
    {
        return response()->json(['status'=>true,'message'=>'data Recorded Successfully']);
    }
    else{
        return response()->json(['status'=>false,'message'=>'Something Error Occure']);
    }
 }

 public function sm_to_asm(Request $request)
 {
    // dd($request->all());
    $insert=sm_to_asm::create(
        [
     'sm_id'=>$request->sm,
     'asm_id'=>$request->asm,
    ]);
    if($insert->id)
    {
        return response()->json(['status'=>true,'message'=>'data Recorded Successfully']);
    }
    else{
        return response()->json(['status'=>false,'message'=>'Something Error Occure']);
    }
 }

 public function asm_to_sp(Request $request)
 {
    // dd($request->all());
    $insert=asm_to_sp::create(
        [
     'sm_id'=>$request->sm,
     'asm_id'=>$request->asm,
     'sp_id'=>$request->sp,
    ]);
    if($insert->id)
    {
        return response()->json(['status'=>true,'message'=>'data Recorded Successfully']);
    }
    else{
        return response()->json(['status'=>false,'message'=>'Something Error Occure']);
    }
 }
 public function get_photo(Request $request)
 {
    $insert=Get_photo::create(
        [
     'journey_id'=>$request->journey_id,
     'user_id'=>$request->user_id,
     'name'=>$request->name,
     'visitdetails'=>$request->visitdetails,
     'image'=>$request->image,
    //  if ($request->hasfile('image'))
    //   {
    //        foreach ($request->file('image') as $file) {            
    //           $filename = rand(0000,9999).time() . '.' . $file->getClientOriginalExtension();
    //            $file->move('public/images/', $filename);
    //            $insert = new get_photo;
    //            $insert->image = $filename;
    //            $insert->save();
    //        }
    //     }
    ]);
    if($insert->id)
    {
        return response()->json(['status'=>true,'message'=>'data Recorded Successfully']);
    }
    else{
        return response()->json(['status'=>false,'message'=>'Something Error Occure']);
    }

 }

 public function tracking(Request $request)
 {
    $insert=tracking::create([
        'user_id'=>$request->user_id,
        'latitude'=>$request->latitude,
        'longitude'=>$request->longitude,
    ]);
if($insert->id){
    return response()->json(['status'=>true,'message'=>'data recorded successfully']);
}
else{
    return response()->json(['status'=>false,'message'=>'Somethig Error Occure']);
}

 }

 public function get_tracking(Request $request)
   {

    //  dd($request->all());
    $get_tracking=tracking::where('user_id',$request->user_id)
    ->where(DB::raw("DATE(created_at) = '".date('Y-m-d')."'"))
    ->get();
    

    if($get_tracking)
     {
         return response()->json(['status'=>true,'data'=>$get_tracking]);
     }
     else
     {
         return response()->json(['status'=>false,'message'=>'data not found']);
     }
   
   }



}